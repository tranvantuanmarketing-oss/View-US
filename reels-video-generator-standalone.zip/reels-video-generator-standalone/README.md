# Reels Story Studio Portable (Standalone)

Tool tạo video Facebook Reels / TikTok độc lập 9:16 chạy trên máy local cá nhân (macOS & Windows).

## Tính năng nổi bật
- Độc lập 100%, không cần kết nối server ngoài hay database.
- Tích hợp đúng 5 mẫu video thịnh hành nhất với 20 bảng màu.
- Tự động co giãn cỡ chữ (auto-fit typography) chuẩn xác, không tràn viền.
- Ghép nhạc nền mượt mà với hiệu ứng fade-in / fade-out.
- Xuất video MP4 H.264 1080×1920 sắc nét kèm file caption và comment 1.
- Hỗ trợ tải trọn gói file ZIP.

## Khởi động
- **macOS:** Click đúp vào `start.command`
- **Windows:** Click đúp vào `start.bat`
- **Dòng lệnh:** `npm install && npm start` (Truy cập `http://localhost:8090`)

Xem hướng dẫn chi tiết tại [HUONG_DAN_CAI_DAT_VA_SU_DUNG.md](HUONG_DAN_CAI_DAT_VA_SU_DUNG.md).
