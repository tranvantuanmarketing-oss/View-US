---
name: "blogbio"
description: Viết tiếp truyện drama thành ĐỦ 15 chương cho Blogbio từ Part 1 + Part 2 người dùng dán vào (chữ hoặc ảnh chụp), đúng ngôn ngữ của bài dán, xuất 2 file riêng gồm file chương "CHAPTER N - Tiêu đề" sẵn để copy dán vào Create chapter / Analyze chapters, và file Series (Title, Slug, Description). Dùng skill này BẤT CỨ KHI NÀO người dùng gõ /blogbio, nhắc Blogbio, blog, Series, Chapter, "15 tập", "15 part", "viết đủ part 1-15", "xuất truyện lên web/blog", "chia chương", hoặc dán caption + comment (Part 1, Part 2 / Deel / Partie / Część / Teil) và muốn viết thành truyện web nhiều phần – kể cả khi chỉ nói ngắn như "blogbio bài này", "làm 15 tập", "viết blog". Không tự đăng bài hay thay đổi website.
---

# BLOGBIO – Viết đủ 15 chương từ Part 1 + Part 2

## Đầu vào
- Người dùng dán Part 1 và Part 2 (văn bản, hoặc ảnh chụp caption/comment). Đọc kỹ cả ảnh.
- **Ngôn ngữ đầu ra = ngôn ngữ của bài dán vào** (Anh, Pháp, Hà Lan, Ba Lan, Đức…). Không suy theo tên Page. Bài dán lẫn nhiều ngôn ngữ thì theo ngôn ngữ chiếm phần thân truyện.
- Mặc định 15 chương. Chỉ đổi số chương khi người dùng nói rõ.
- Không hỏi lại nếu đã đủ Part 1 + Part 2; viết luôn. Chỉ hỏi khi thiếu hẳn nội dung truyện.

## Cách viết 15 chương
- **CHAPTER 1–2:** dựa sát Part 1 và Part 2 đã dán: giữ tên nhân vật, tình tiết, thứ tự, lời thoại chính và cú twist. Được viết mượt thành văn xuôi đọc web, bổ sung cảm xúc/chi tiết cho đủ dài, nhưng KHÔNG đổi diễn biến. Bỏ toàn bộ phần mồi Facebook: "type YES", "like", "comment", hashtag, "Part 2 in comments", CTA, emoji kêu gọi.
- **CHAPTER 3–15:** viết tiếp từ đúng cliffhanger cuối Part 2. Mỗi chương một diễn biến có ý nghĩa (bằng chứng mới, đối chất, lựa chọn, bí mật lộ ra), không kéo dài lặp ý.
- Mạch gợi ý: 3–5 làm rõ bí ẩn của cliffhanger; 6–9 kẻ xấu phản công, nhân vật chính bị dồn ép, manh mối mới; 10–12 thu thập bằng chứng, đồng minh, lật mặt dần; 13–14 đối chất lớn, công lý/pháp lý; 15 kết thúc trọn vẹn, hả hê và nhân văn (đứa trẻ, cuộc sống mới…), không hứa phần tiếp.
- Nhất quán tuyệt đối: tên, tuổi, quan hệ, thời gian, địa điểm, tiền tệ, bằng chứng. Pháp lý/cảnh sát/tòa án hợp lý theo quốc gia của truyện.
- Chương chưa cuối kết ở một bước ngoặt tự nhiên; đổi kiểu cliffhanger, không dùng một mánh lặp lại.
- Độ dài: TỔNG CẢ TRUYỆN khoảng 7.000–10.000 từ (trung bình ~470–670 từ mỗi chương; chương 1–2 và chương cao trào có thể dài hơn một chút). Không vượt 10.000 từ, không dưới 7.000 từ. Văn đọc web: đoạn ngắn 1–4 câu, lời thoại xuống dòng riêng.
- Truyện hư cấu: không ghi "chuyện có thật/đã xác minh". Cảnh bạo lực không mô tả máu me chi tiết.

## Định dạng đầu ra (bắt buộc)
Chỉ xuất nội dung truyện, không thêm gì khác vào khối copy:

```text
CHAPTER 1 - Tiêu đề chương một

Nội dung chương một.

CHAPTER 2 - Tiêu đề chương hai

Nội dung chương hai.
```

1. Mỗi tiêu đề một dòng riêng, đúng dạng `CHAPTER N - Tiêu đề`, số 1→15 liên tiếp, gạch ngang ASCII `-`. Từ khóa `CHAPTER` luôn tiếng Anh; tiêu đề và thân truyện bằng ngôn ngữ của bài dán.
2. Không `#`, `##`, `**`, HTML, JSON, link, emoji kêu gọi, hashtag, prompt ảnh, ghi chú hay bản dịch trong khối truyện.
3. Một dòng trống sau tiêu đề và giữa các đoạn. Không lặp tiêu đề chương trong thân bài; không có dòng nào khác bắt đầu bằng `CHAPTER số -`.
4. KHÔNG kèm hướng dẫn nhập CMS. KHÔNG bản dịch tiếng Việt trừ khi được yêu cầu.
5. File chương là TXT UTF-8 thuần (không BOM, xuống dòng LF): chỉ chứa nội dung truyện, giữ nguyên câu chữ và marker `CHAPTER N - Tiêu đề`. Không định dạng code/monospace, không HTML, không font riêng, không ký tự ẩn (khoảng trắng không ngắt, zero-width), không khoảng trắng cuối dòng, tối đa 1 dòng trống liên tiếp. Người dùng dán thẳng vào trình soạn thảo web.
6. KHÔNG hiển thị nội dung truyện trong khối code trong chat; chỉ giao qua file.
7. KHÔNG trộn thông tin Series (Title/Slug/Description) vào file chương. Series luôn xuất ở file riêng (xem dưới).

## File Series (luôn xuất kèm, file riêng)
Tên file: `<slug>-series.txt`, cùng slug với file chương. Nội dung đúng mẫu sau, nhãn giữ tiếng Anh, giá trị bằng ngôn ngữ của truyện:

```text
Title:
[Tên truyện, bằng ngôn ngữ của truyện]

Slug:
[chữ thường, không dấu, nối bằng gạch ngang – trùng slug tên file]

Description:
[2–4 câu giới thiệu hấp dẫn, bằng ngôn ngữ của truyện; nêu nhân vật chính, bối cảnh và xung đột mở đầu; KHÔNG tiết lộ cú twist cuối hay kết thúc]

Chapters:
15 / 15
```

- Dòng Chapters chỉ là thông tin vận hành, không dán vào Description.
- Không bịa link ảnh bìa. Không thêm prompt ảnh bìa trừ khi người dùng yêu cầu.
- File Series cũng là TXT UTF-8 thuần như file chương. Trong chat, ngoài 2 file, ghi lại Title, Slug, Description dạng văn bản thường (không khối code, không monospace) để copy.

## Cách xuất
- Vì 15 chương rất dài, ghi vào file UTF-8 `.txt` trong `/mnt/user-data/outputs/`, tên `<slug-tiêu-đề-truyện>-chapters.txt` (chữ thường, không dấu, gạch ngang). Viết lần lượt từng nhóm chương rồi nối vào cùng file (vd: 1–4, 5–8, 9–12, 13–15), sau đó tạo file `<slug>-series.txt`, kiểm tra và present cả 2 file (file chương trước, file Series sau).
- Kiểm tra trước khi giao: đủ 15 marker `CHAPTER 1`…`CHAPTER 15`, không trùng, không chương rỗng, không câu bị cắt, không lọt CTA/hashtag, tổng số từ nằm trong 7.000–10.000. Có thể dùng `grep -c "^CHAPTER [0-9]* - "` để đếm chương và `wc -w` để đếm từ.
- Trước khi present, chuẩn hóa cả 2 file bằng Python: đọc `utf-8-sig`, chuẩn NFC, đổi CRLF thành LF, thay `\u00a0` bằng khoảng trắng, xóa `\u200b`, bỏ khoảng trắng cuối dòng, gộp 3+ dòng trống thành 1 dòng trống, ghi lại `encoding='utf-8', newline='\n'`. Kiểm tra không còn ký tự `<`, `>`, `` ` ``, `*`, `#` trong file chương.
- Nếu không thể viết đủ trong một lượt: xuất trọn các chương đã xong, báo rõ "đã xong chương 1–X", lượt sau viết tiếp từ X+1 và nối vào cùng file.
- Lời nhắn ngoài file: 1 câu tiếng Việt, ví dụ "Đã xong đủ 15 chương bằng tiếng [ngôn ngữ] và file Series riêng; copy file chương dán vào Create chapter, thông tin Series dán vào form tạo Series." Kèm Title / Slug / Description dạng văn bản thường. Không tuyên bố đã đăng.
